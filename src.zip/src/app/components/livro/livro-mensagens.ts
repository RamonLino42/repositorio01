export enum LivroMensagrns{
    CreateOkPtBr = "Livro Inserido com Sucesso",

    EditOkPtBr = "Livro alterado com sucesso",

    Error400ErrorBedRequestPtBr = "Algum dado não foi enviado ou esta incoreto. Verifique os dados novamente",
    Error500InternalServerErrorPtBr ="Erro no Servidor Entre em contato com a equipe de suporte",
    Error404NotFound = "Livro não existente",
    
}