import { NgModule } from '@angular/core';
import { HomeComponent } from './home.component';




@NgModule({
  declarations: [HomeComponent],
  imports: [
  ],
  exports:[
  ]
})
export class HomeModule { }
